# Graeham Watts — Brand Reference

Single source of truth for all brand visual rules across every skill.
Reference this file from any new skill instead of duplicating brand specs.

## Color Palette

| Token | Hex | Usage |
|---|---|---|
| `--u-navy` | `#1B2A4A` | Structural — backgrounds, headers, body text on light backgrounds |
| `--u-gold` | `#C5A258` | Brand accent — CTAs, badges, opportunity scores, brand moments only |
| `--u-green` | `#2e7d32` | Semantic positive — "ready", "completed", "passed" |
| `--u-red` | `#c62828` | Semantic negative — "error", "failed", "alert" |
| `--u-bg` | `#F7F5EF` | Page background (cream) |
| `--u-card` | `#FFFFFF` | Card / surface background |
| `--u-border` | `rgba(27, 42, 74, 0.10)` | Card borders, dividers |
| `--u-text` | `#1B2A4A` | Body text on light backgrounds |
| `--u-muted` | `#5a6478` | Secondary text, metadata |

**Gold is sacred.** Use it for: primary CTA buttons, opportunity score values, the
PICKED/SELECTED tag, hero accents, brand identity moments. Maximum ~10
instances per dashboard. Don't use it for general UI chrome — use navy and
gray for that.

## Typography

- **Display:** `Plus Jakarta Sans` (weights 600, 700, 800)
- **Body:** `DM Sans` (weights 400, 500, 700)
- **Mono / code:** system mono (`ui-monospace, Consolas, monospace`)

Both fonts come from Google Fonts. Always include a fallback chain:
```css
font-family: 'Plus Jakarta Sans', 'DM Sans', system-ui, sans-serif;
font-family: 'DM Sans', system-ui, sans-serif;
```

## Component shapes

- **Card border-radius:** `12px`
- **Button border-radius:** `8px`
- **Pill / badge border-radius:** `20px`
- **Card padding:** `16-22px`
- **Card shadow:** `0 2px 10px rgba(27, 42, 74, 0.06)` (light) or `0 6px 20px rgba(27, 42, 74, 0.10)` (lifted)

## Dashboard / email overlay stylesheet

For HTML output, embed the brand CSS rules above directly in your dashboard `<style>` block.

## Identity strings

> **SINGLE SOURCE OF TRUTH:** `skills/shared-references/identity.json`
>
> Brand identity (name, DRE, contact info) lives in `identity.json` and
> nowhere else. Skills that need these values should read from that file
> at runtime — never hardcode them. The audit script
> `scripts/verify_brand_identity.py` runs as a pre-push hook and refuses
> to ship if any blocked value (e.g. an incorrect DRE) appears anywhere
> in the repo outside `identity.json` itself.
>
> If you're hand-writing a new template that includes the DRE, copy from
> `identity.json` and add a comment: `# DRE from skills/shared-references/identity.json`.
> That makes the dependency explicit and grep-able.

For human reference (do not hardcode — read from identity.json):

- Name: Graeham Watts
- Title: REALTOR
- Brokerage: Intero Real Estate
- DRE: see identity.json
- Email: see identity.json
- Website: see identity.json

## Markets

- Primary: East Palo Alto
- Secondary: Redwood City, Palo Alto, Menlo Park, San Mateo County, Peninsula

## Fair Housing guardrails

Always present in any content output:
- No demographic descriptors (race, religion, national origin, family status,
  disability)
- No "safe / good / family-friendly / up-and-coming" as proxies for
  demographic signaling
- No school rankings as a primary selling point
- Public safety content permitted ONLY when framed as statistics + public
  policy, never as neighborhood character proxy

---

*Update history: created April 21, 2026 to consolidate brand specs from
`content-creation-engine/SKILL.md` and the dashboard CSS overlay.*
